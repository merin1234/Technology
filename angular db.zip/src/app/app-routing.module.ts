import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Header1Component } from './header1/header1.component';
import { RootComponent } from './root/root.component';

const routes: Routes = [{path:"home",component:Header1Component},
{path:'apply',component:RootComponent},
{path:'login',component:Header1Component}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
