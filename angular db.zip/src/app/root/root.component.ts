import { Component, OnInit } from '@angular/core';
import { FirstserviceService } from '../firstservice.service';
import{student} from '../student';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  styleUrls: ['./root.component.css']
})
export class RootComponent implements OnInit {
student=new student();
isRegistered=false;

  constructor(private applyservice:FirstserviceService) { }

  ngOnInit() {
  }
  registration(f: NgForm){
    this.applyservice.store(this.student).subscribe(
      data =>
      {
      this.isRegistered=true;
      console.log("registered successfull");
      f.reset();
      },
      (err)=> {
        this.isRegistered=false;
      }
    );
  }
    
}
