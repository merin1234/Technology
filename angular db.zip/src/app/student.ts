export class student{
    id:Number;
    email:String;
    psw:String;
    status:Number;
    constructor(){
        this.email='';
        this.psw='';
        
    }
}