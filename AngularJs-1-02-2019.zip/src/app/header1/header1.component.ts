import { Component, OnInit } from '@angular/core';
import { checkAndUpdateBinding } from '@angular/core/src/view/util';

@Component({
  selector: 'app-header1',
  templateUrl: './header1.component.html',
  styleUrls: ['./header1.component.css']
})
export class Header1Component implements OnInit {
  
user:any;
check:boolean=true;
  constructor() { 
 this.user=
 {name:'merin mary babu',
  job:'student',address:'valiyaparambil',
  phone:[]
};
} 
togglecheck(){
  this.check=!this.check;
}
  ngOnInit() {
  }

}
