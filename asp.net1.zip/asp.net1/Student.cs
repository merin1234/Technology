﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVCApplication.Models
{
    public class Student
    {
        [Required(ErrorMessage="Cant be empty")]
        [Display(Name="Name")]
        //[RegularExpression()]
        public string Sname { get; set; }

        [Required(ErrorMessage = "Cant be empty")]
        [Display(Name = "Address")]
        [DataType(DataType.MultilineText)]
        public string Saddress { get; set;}

        public Genderlist Gender { get; set; }

        public Courselist Course { get; set; }

        [Required(ErrorMessage = "Cant be empty")]
        [Display(Name = " Email")]
        [RegularExpression(@"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$",
         ErrorMessage = "Email Format is wrong")]
        [DataType(DataType.EmailAddress)]
        public string Semail { get; set; }

        [Required(ErrorMessage = "Cant be empty")]
        [Display(Name = "Username")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Cant be empty")]
        [Display(Name = " Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        
        [Required(ErrorMessage = "Confirm Password required")]
        [CompareAttribute("Password", ErrorMessage = "Password doesn't match.")]
        public string ConfirmPassowrd { get; set; }


    }

    public enum Genderlist
    {
        Male, 
        Female
    }
    public enum Courselist
    {
        MCA,
        MBA
    }
}